export const env = {
  apiKey: "AIzaSyD_osvSJWMtXOT2vN4wFZbhvPHbTZMq4J8",
  authDomain: "mooc-2f58d.firebaseapp.com",
  databaseURL: "https://mooc-2f58d-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "mooc-2f58d",
  storageBucket: "mooc-2f58d.appspot.com",
  messagingSenderId: "580925532827",
  appId: "1:580925532827:web:ad4f895ddf5d8f64daf43e"
}